"""
clean_fitness_data.py
=====================
Bengaluru Fitness Centre – Data Cleaning Script
Author : Archit Gupta
Date   : 16th May 2026

Cleaning steps performed (documented inline per spec):
  1. Schema harmonisation across sources
  2. Duplicate removal (exact + near-duplicate flagging)
  3. Missing contact flagging
  4. Rating normalisation & zero-rating removal
  5. Locality name standardisation
  6. Category standardisation
  7. Phone number validation
  8. Price range normalisation
"""

import os
import re
import logging
import pandas as pd
import numpy as np

# ---------------------------------------------------------------------------
# Paths  (relative to this script — works on any machine)
# ---------------------------------------------------------------------------
BASE_DIR    = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW_DIR     = os.path.join(BASE_DIR, "data", "raw")
CLEANED_DIR = os.path.join(BASE_DIR, "data", "cleaned")
os.makedirs(CLEANED_DIR, exist_ok=True)

# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(os.path.join(RAW_DIR, "cleaning_log.txt")),
        logging.StreamHandler(),
    ],
)
log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# 1. SCHEMA HARMONISATION
# ---------------------------------------------------------------------------
COLUMN_MAP_GOOGLE = {
    "fitness_centre_name": "fitness_centre_name",
    "address":             "address",
    "area_locality":       "area_locality",
    "city":                "city",
    "latitude":            "latitude",
    "longitude":           "longitude",
    "zone":                "zone",
    "rating":              "rating",
    "number_of_reviews":   "number_of_reviews",
    "category":            "category",
    "phone_number":        "phone_number",
    "email_address":       "email_address",
    "website_social_url":  "website_social_url",
    "operating_hours":     "operating_hours",
    "price_range":         "price_range",
    "source":              "source",
}

COLUMN_MAP_JUSTDIAL = {
    "business_name":   "fitness_centre_name",
    "full_address":    "address",
    "locality":        "area_locality",
    "city":            "city",
    "lat":             "latitude",
    "lon":             "longitude",
    "zone":            "zone",
    "star_rating":     "rating",
    "total_ratings":   "number_of_reviews",
    "category_type":   "category",
    "contact":         "phone_number",
    "email":           "email_address",
    "web_link":        "website_social_url",
    "timings":         "operating_hours",
    "fee_range":       "price_range",
    "source":          "source",
}

def harmonise(df, col_map):
    df = df.rename(columns=col_map)
    return df[[c for c in col_map.values() if c in df.columns]]


# ---------------------------------------------------------------------------
# 2. LOCALITY NAME STANDARDISATION MAP
# ---------------------------------------------------------------------------
LOCALITY_ALIASES = {
    "Koramangala 1st Block":    "Koramangala",
    "Koramangala 5th Block":    "Koramangala",
    "Koramangala 6th Block":    "Koramangala",
    "Indiranagar 100ft Road":   "Indiranagar",
    "Indira Nagar":             "Indiranagar",
    "HSR":                      "HSR Layout",
    "Hsr Layout":               "HSR Layout",
    "BTM":                      "BTM Layout",
    "Btm Layout":               "BTM Layout",
    "JP Nagar Phase 1":         "JP Nagar",
    "J P Nagar":                "JP Nagar",
    "Electronic City Phase 1":  "Electronic City",
    "Electronic City Phase 2":  "Electronic City",
    "Ecity":                    "Electronic City",
    "MG Rd":                    "MG Road",
    "Mg Road":                  "MG Road",
    "Majestic":                 "Shivajinagar",
    "Hebbal Flyover":           "Hebbal",
    "Old Madras Road":          "KR Puram",
    "KR Puram":                 "KR Puram",
    "Bellandur Gate":           "Bellandur",
    "Sarjapur Road":            "Sarjapur",
    "Bannerghatta":             "Bannerghatta Road",
    "Yelahanka New Town":       "Yelahanka",
    "Rajaji Nagar":             "Rajajinagar",
    "Rajaji Nagar Industrial":  "Rajajinagar",
    "Marathahalli Bridge":      "Marathahalli",
    "Marathahalli Colony":      "Marathahalli",
    "Vijayanagar Extension":    "Vijayanagar",
    "Vijay Nagar":              "Vijayanagar",
    "Domlur Layout":            "Domlur",
    "Old Airport Road Extension": "Old Airport Road",
    "Nagarbhavi 1st Stage":     "Nagarbhavi",
    "RT Nagar Main":            "RT Nagar",
    "Peenya Industrial Area":   "Peenya",
    "Yeshwanthpur Circle":      "Yeshwanthpur",
    "Chamrajpet Layout":        "Chamrajpet",
    "Seshadri Puram":           "Seshadripuram",
    "Uttarahalli Main Road":    "Uttarahalli",
    "Kengeri Satellite Town":   "Kengeri",
    "Kengeri Bus Stand":        "Kengeri",
}

def standardise_locality(name):
    if pd.isna(name):
        return name
    stripped = str(name).strip()
    return LOCALITY_ALIASES.get(stripped, stripped)


# ---------------------------------------------------------------------------
# 3. CATEGORY STANDARDISATION MAP
# ---------------------------------------------------------------------------
CATEGORY_ALIASES = {
    "gym":                   "Gym / Fitness Studio",
    "fitness":               "Gym / Fitness Studio",
    "fitness studio":        "Gym / Fitness Studio",
    "fitness centre":        "Gym / Fitness Studio",
    "health club":           "Gym / Fitness Studio",
    "weight training":       "Gym / Fitness Studio",
    "yoga":                  "Yoga Centre",
    "yoga studio":           "Yoga Centre",
    "yoga wellness":         "Yoga Centre",
    "yoga centre":           "Yoga Centre",
    "dance":                 "Dance / Zumba Studio",
    "dance studio":          "Dance / Zumba Studio",
    "zumba":                 "Dance / Zumba Studio",
    "zumba studio":          "Dance / Zumba Studio",
    "dance academy":         "Dance / Zumba Studio",
    "crossfit":              "CrossFit Box",
    "crossfit box":          "CrossFit Box",
    "crossfit gym":          "CrossFit Box",
    "calisthenics":          "Calisthenics Park / Training Centre",
    "street workout":        "Calisthenics Park / Training Centre",
    "outdoor fitness":       "Calisthenics Park / Training Centre",
    "pilates":               "Pilates Studio",
    "pilates studio":        "Pilates Studio",
    "reformer pilates":      "Pilates Studio",
    "karate":                "Karate Dojo",
    "karate dojo":           "Karate Dojo",
    "martial arts":          "Karate Dojo",
    "taekwondo":             "Taekwondo Academy",
    "tkd":                   "Taekwondo Academy",
    "taekwondo academy":     "Taekwondo Academy",
    "kickboxing":            "Kickboxing Studio",
    "mma":                   "Kickboxing Studio",
    "combat sports":         "Kickboxing Studio",
    "muay thai":             "Kickboxing Studio",
}

STANDARD_CATEGORIES = [
    "Gym / Fitness Studio",
    "Yoga Centre",
    "Dance / Zumba Studio",
    "CrossFit Box",
    "Calisthenics Park / Training Centre",
    "Pilates Studio",
    "Karate Dojo",
    "Taekwondo Academy",
    "Kickboxing Studio",
]

def standardise_category(cat):
    if pd.isna(cat):
        return "Gym / Fitness Studio"
    key = str(cat).strip().lower()
    if cat in STANDARD_CATEGORIES:
        return cat
    return CATEGORY_ALIASES.get(key, cat)


# ---------------------------------------------------------------------------
# 4. PHONE VALIDATION
# ---------------------------------------------------------------------------
PHONE_RE = re.compile(
    r"^(\+91[\s\-]?)?([6-9]\d{9}|0\d{2,4}[\s\-]?\d{6,8})$"
)

def validate_phone(phone):
    if pd.isna(phone):
        return False
    digits_only = re.sub(r"[\s\-\+]", "", str(phone))
    # Remove country code if present
    if digits_only.startswith("91") and len(digits_only) == 12:
        digits_only = digits_only[2:]
    return bool(PHONE_RE.match(str(phone))) or (len(digits_only) == 10 and digits_only[0] in "6789")


# ---------------------------------------------------------------------------
# MAIN CLEANING PIPELINE
# ---------------------------------------------------------------------------
def clean(raw_gm_path: str, raw_jd_path: str, out_csv: str, out_xlsx: str):

    log.info("Loading raw data …")
    df_gm = pd.read_csv(raw_gm_path)
    df_jd = pd.read_csv(raw_jd_path)

    log.info("Raw record counts: Google Maps=%d | Justdial=%d", len(df_gm), len(df_jd))

    # ── Step 1: Harmonise schemas ─────────────────────────────────────────
    df_gm = harmonise(df_gm, COLUMN_MAP_GOOGLE)
    df_jd = harmonise(df_jd, COLUMN_MAP_JUSTDIAL)
    df = pd.concat([df_gm, df_jd], ignore_index=True)
    log.info("Step 1 – Merged dataset: %d rows", len(df))

    # ── Step 2: Duplicate removal ─────────────────────────────────────────
    before = len(df)
    df = df.drop_duplicates(
        subset=["fitness_centre_name", "address"], keep="first"
    )
    log.info("Step 2 – Exact duplicates removed: %d → %d", before, len(df))

    # Near-duplicate flag: same name in same locality (different address)
    df["near_duplicate_flag"] = df.duplicated(
        subset=["fitness_centre_name", "area_locality"], keep=False
    )
    nd_count = df["near_duplicate_flag"].sum()
    log.info("         Near-duplicate flag set for %d rows", nd_count)

    # ── Step 3: Missing contact flagging ─────────────────────────────────
    df["missing_contact"] = df["phone_number"].isna() & df["email_address"].isna()
    log.info("Step 3 – Rows with BOTH phone & email missing: %d",
             df["missing_contact"].sum())

    # ── Step 4: Rating normalisation & zero-rating removal ───────────────
    df["rating"] = pd.to_numeric(df["rating"], errors="coerce")
    df["number_of_reviews"] = pd.to_numeric(
        df["number_of_reviews"], errors="coerce"
    ).fillna(0).astype(int)

    # Remove entries where rating = 0 AND reviews = 0 (uninformative)
    before = len(df)
    df = df[~((df["rating"] == 0) & (df["number_of_reviews"] == 0))]
    log.info("Step 4 – Zero-rating/zero-review rows removed: %d → %d",
             before, len(df))

    # Clamp ratings to [1, 5]
    df["rating"] = df["rating"].clip(lower=1.0, upper=5.0)
    # Round to 1 decimal
    df["rating"] = df["rating"].round(1)

    # ── Step 5: Locality standardisation ─────────────────────────────────
    df["area_locality"] = df["area_locality"].apply(standardise_locality)
    log.info("Step 5 – Locality names standardised")

    # ── Step 6: Category standardisation ─────────────────────────────────
    df["category"] = df["category"].apply(standardise_category)
    log.info("Step 6 – Categories standardised")

    # ── Step 7: Phone number validation ──────────────────────────────────
    df["phone_valid"] = df["phone_number"].apply(validate_phone)
    invalid_ph = (~df["phone_valid"] & df["phone_number"].notna()).sum()
    log.info("Step 7 – Invalid phone numbers flagged: %d", invalid_ph)

    # ── Step 8: Price range normalisation ────────────────────────────────
    PRICE_MAP = {
        "budget":  "Budget",
        "mid":     "Mid",
        "premium": "Premium",
        "low":     "Budget",
        "high":    "Premium",
        "medium":  "Mid",
    }
    df["price_range"] = (
        df["price_range"]
        .str.strip()
        .map(lambda x: PRICE_MAP.get(str(x).lower(), x) if pd.notna(x) else x)
    )
    log.info("Step 8 – Price ranges normalised")

    # ── Final column ordering ────────────────────────────────────────────
    FINAL_COLS = [
        "fitness_centre_name", "address", "area_locality", "city",
        "zone", "latitude", "longitude",
        "rating", "number_of_reviews",
        "category", "phone_number", "email_address",
        "website_social_url", "operating_hours", "price_range",
        "source", "phone_valid", "missing_contact", "near_duplicate_flag",
    ]
    df = df[[c for c in FINAL_COLS if c in df.columns]]
    df = df.reset_index(drop=True)

    log.info("Final cleaned dataset: %d records across %d localities",
             len(df), df["area_locality"].nunique())
    log.info("Category distribution:\n%s", df["category"].value_counts().to_string())

    # ── Save CSV ─────────────────────────────────────────────────────────
    df.to_csv(out_csv, index=False, encoding="utf-8")
    log.info("CSV saved → %s", out_csv)

    # ── Save Excel (formatted) ────────────────────────────────────────────
    _save_excel(df, out_xlsx)
    log.info("Excel saved → %s", out_xlsx)

    return df


def _save_excel(df: pd.DataFrame, path: str):
    from openpyxl import Workbook
    from openpyxl.styles import (Font, PatternFill, Alignment,
                                  Border, Side, GradientFill)
    from openpyxl.utils import get_column_letter

    wb = Workbook()
    ws = wb.active
    ws.title = "Cleaned Data"

    HEADER_FILL  = PatternFill("solid", fgColor="1F4E79")
    HEADER_FONT  = Font(name="Arial", bold=True, color="FFFFFF", size=10)
    ALT_FILL     = PatternFill("solid", fgColor="D6E4F0")
    BODY_FONT    = Font(name="Arial", size=9)
    BORDER_SIDE  = Side(style="thin", color="B0C4DE")
    THIN_BORDER  = Border(
        left=BORDER_SIDE, right=BORDER_SIDE,
        top=BORDER_SIDE,  bottom=BORDER_SIDE
    )

    # Headers
    headers = list(df.columns)
    for col_idx, col_name in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=col_idx, value=col_name.replace("_", " ").title())
        cell.font      = HEADER_FONT
        cell.fill      = HEADER_FILL
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border    = THIN_BORDER

    # Data rows
    for row_idx, row in enumerate(df.itertuples(index=False), start=2):
        fill = ALT_FILL if row_idx % 2 == 0 else PatternFill("solid", fgColor="FFFFFF")
        for col_idx, value in enumerate(row, start=1):
            cell = ws.cell(row=row_idx, column=col_idx, value=value)
            cell.font      = BODY_FONT
            cell.fill      = fill
            cell.alignment = Alignment(vertical="center")
            cell.border    = THIN_BORDER

    # Column widths
    col_widths = {
        "fitness_centre_name": 32, "address": 45, "area_locality": 22,
        "city": 12, "zone": 10, "latitude": 12, "longitude": 12,
        "rating": 8, "number_of_reviews": 16, "category": 30,
        "phone_number": 18, "email_address": 30, "website_social_url": 35,
        "operating_hours": 20, "price_range": 12, "source": 14,
        "phone_valid": 12, "missing_contact": 16, "near_duplicate_flag": 20,
    }
    for col_idx, col_name in enumerate(headers, start=1):
        width = col_widths.get(col_name, 15)
        ws.column_dimensions[get_column_letter(col_idx)].width = width

    # Freeze header row
    ws.freeze_panes = "A2"

    # Auto-filter
    ws.auto_filter.ref = ws.dimensions

    # Row height for header
    ws.row_dimensions[1].height = 30

    # Summary sheet
    ws2 = wb.create_sheet("Summary")
    ws2["A1"] = "Category"
    ws2["B1"] = "Count"
    ws2["C1"] = "Avg Rating"
    ws2["D1"] = "Avg Reviews"
    for cell in ws2["A1:D1"][0]:
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal="center")

    cat_summary = (
        df.groupby("category")
        .agg(Count=("fitness_centre_name", "count"),
             Avg_Rating=("rating", "mean"),
             Avg_Reviews=("number_of_reviews", "mean"))
        .reset_index()
        .sort_values("Count", ascending=False)
    )
    for r_i, row in enumerate(cat_summary.itertuples(index=False), start=2):
        ws2.cell(row=r_i, column=1, value=row.category)
        ws2.cell(row=r_i, column=2, value=row.Count)
        ws2.cell(row=r_i, column=3, value=round(row.Avg_Rating, 2))
        ws2.cell(row=r_i, column=4, value=round(row.Avg_Reviews, 1))

    for col in ["A", "B", "C", "D"]:
        ws2.column_dimensions[col].width = 30

    wb.save(path)


# ---------------------------------------------------------------------------
if __name__ == "__main__":
    df = clean(
        raw_gm_path=os.path.join(RAW_DIR,     "raw_google_maps.csv"),
        raw_jd_path=os.path.join(RAW_DIR,     "raw_justdial.csv"),
        out_csv    =os.path.join(CLEANED_DIR, "Bengaluru_fitness_data.csv"),
        out_xlsx   =os.path.join(CLEANED_DIR, "Bengaluru_fitness_data.xlsx"),
    )
    log.info("Cleaning complete. Final shape: %s", df.shape)
