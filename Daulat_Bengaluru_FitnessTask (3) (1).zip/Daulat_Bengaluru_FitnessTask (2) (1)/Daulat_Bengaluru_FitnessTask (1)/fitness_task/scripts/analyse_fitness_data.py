"""
analyse_fitness_data.py
=======================
Bengaluru Fitness Centre – Analysis & Visualisation Script
Author : Archit Gupta
Date   : 16thMay 2026

Sections:
  4.1 Geographic & Regional Analysis
  4.2 Target Demographic Proximity Analysis
  4.3 Category-wise Analysis
  4.4 Rating & Review Analysis
  4.5 Business Recommendation (outputs JSON used by report generator)
"""

import os
import json
import warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.ticker as mticker
from matplotlib.gridspec import GridSpec
from scipy import stats
import seaborn as sns

warnings.filterwarnings("ignore")

# ---------------------------------------------------------------------------
# Style
# ---------------------------------------------------------------------------
BRAND_BLUE   = "#1F4E79"
BRAND_ORANGE = "#E8641A"
BRAND_GREEN  = "#2E7D32"
BRAND_RED    = "#C62828"
BRAND_PURPLE = "#6A1B9A"
ACCENT_TEAL  = "#00838F"
PALETTE = [BRAND_BLUE, BRAND_ORANGE, BRAND_GREEN, BRAND_RED,
           BRAND_PURPLE, ACCENT_TEAL, "#F9A825", "#558B2F", "#AD1457"]

plt.rcParams.update({
    "font.family":        "DejaVu Sans",
    "font.size":          10,
    "axes.titlesize":     13,
    "axes.titleweight":   "bold",
    "axes.labelsize":     10,
    "axes.spines.top":    False,
    "axes.spines.right":  False,
    "axes.grid":          True,
    "grid.alpha":         0.3,
    "grid.linestyle":     "--",
    "figure.facecolor":   "white",
    "savefig.dpi":        180,
    "savefig.bbox":       "tight",
    "savefig.facecolor":  "white",
})

# ---------------------------------------------------------------------------
# Paths  (relative to this script — works on any machine)
# ---------------------------------------------------------------------------
BASE_DIR    = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIG_DIR     = os.path.join(BASE_DIR, "figures")
DATA_PATH   = os.path.join(BASE_DIR, "data", "cleaned", "Bengaluru_fitness_data.csv")
CLEANED_DIR = os.path.join(BASE_DIR, "data", "cleaned")

# ---------------------------------------------------------------------------
# Known proximity data (colleges, IT parks, metro stations near each locality)
# These are curated from public knowledge; in production geopy would compute
# exact haversine distances from OpenStreetMap / Overpass API coordinates.
# ---------------------------------------------------------------------------
PROXIMITY = {
    # locality: (college_score, it_park_score, metro_score)  — each 0-10
    "Koramangala":          (7, 9, 6),
    "Indiranagar":          (6, 7, 9),
    "HSR Layout":           (5, 9, 5),
    "Whitefield":           (4, 10, 7),
    "Marathahalli":         (3, 9, 6),
    "Electronic City":      (3, 10, 4),
    "Jayanagar":            (7, 4, 7),
    "JP Nagar":             (6, 5, 6),
    "Malleshwaram":         (8, 3, 9),
    "Rajajinagar":          (6, 3, 8),
    "Banashankari":         (7, 3, 7),
    "BTM Layout":           (6, 8, 5),
    "Marathahalli Bridge":  (3, 9, 6),
    "Yelahanka":            (5, 4, 5),
    "Hebbal":               (5, 6, 8),
    "Bellandur":            (3, 9, 4),
    "Sarjapur":             (3, 8, 3),
    "Bannerghatta Road":    (4, 5, 4),
    "Cunningham Road":      (5, 6, 9),
    "MG Road":              (4, 6, 10),
    "Brigade Road":         (4, 6, 10),
    "Shivajinagar":         (6, 4, 9),
    "Basavangudi":          (8, 3, 6),
    "RT Nagar":             (5, 2, 7),
    "Kamanahalli":          (4, 4, 6),
    "KR Puram":             (4, 6, 7),
    "Nagarbhavi":           (7, 3, 4),
    "Vijayanagar":          (6, 3, 7),
    "Mysore Road":          (4, 4, 6),
    "Yeshwanthpur":         (4, 5, 8),
    "Peenya":               (3, 6, 7),
    "Domlur":               (5, 6, 8),
    "Old Airport Road":     (4, 6, 7),
    "Seshadripuram":        (8, 3, 8),
    "Chamrajpet":           (5, 3, 7),
    "Nagawara":             (5, 3, 6),
    "Thanisandra":          (4, 4, 5),
    "Ramamurthy Nagar":     (3, 4, 5),
    "Uttarahalli":          (4, 3, 4),
    "Kengeri":              (5, 2, 6),
}


def load_data():
    df = pd.read_csv(DATA_PATH)
    return df


# ---------------------------------------------------------------------------
# 4.1 Geographic & Regional Analysis
# ---------------------------------------------------------------------------
def analysis_geographic(df):
    print("\n── 4.1 Geographic & Regional Analysis ──")

    locality_counts = (
        df.groupby("area_locality")
        .size()
        .reset_index(name="centre_count")
        .sort_values("centre_count", ascending=False)
    )

    top5 = locality_counts.head(5)
    print("Top 5 localities by centre count:")
    print(top5.to_string(index=False))

    # ── Fig 1: Top 15 localities bar chart ───────────────────────────────
    fig, ax = plt.subplots(figsize=(12, 6))
    top15 = locality_counts.head(15)
    colors = [BRAND_ORANGE if i < 5 else BRAND_BLUE for i in range(len(top15))]
    bars = ax.barh(top15["area_locality"][::-1],
                   top15["centre_count"][::-1],
                   color=colors[::-1], edgecolor="white", height=0.7)
    for bar, val in zip(bars, top15["centre_count"][::-1]):
        ax.text(val + 0.5, bar.get_y() + bar.get_height() / 2,
                str(val), va="center", fontsize=9, color="#333")
    ax.set_xlabel("Number of Fitness Centres")
    ax.set_title("Fitness Centre Density by Locality – Top 15 Areas in Bengaluru")
    p1 = mpatches.Patch(color=BRAND_ORANGE, label="Top 5 localities")
    p2 = mpatches.Patch(color=BRAND_BLUE,   label="Localities 6–15")
    ax.legend(handles=[p1, p2], loc="lower right")
    ax.set_xlim(0, top15["centre_count"].max() * 1.12)
    plt.tight_layout()
    plt.savefig(f"{FIG_DIR}/fig1_locality_density.png")
    plt.close()
    print("Saved fig1_locality_density.png")

    # ── Opportunity Gap: high demand, low supply ─────────────────────────
    # Demand proxy = avg_rating * log(reviews + 1)
    locality_demand = (
        df.groupby("area_locality")
        .agg(
            centre_count=("fitness_centre_name", "count"),
            avg_rating=("rating", "mean"),
            total_reviews=("number_of_reviews", "sum"),
        )
        .reset_index()
    )
    locality_demand["demand_score"] = (
        locality_demand["avg_rating"] *
        np.log1p(locality_demand["total_reviews"])
    )
    # Normalise
    locality_demand["supply_norm"] = (
        locality_demand["centre_count"] /
        locality_demand["centre_count"].max()
    )
    locality_demand["demand_norm"] = (
        locality_demand["demand_score"] /
        locality_demand["demand_score"].max()
    )
    locality_demand["opportunity_gap"] = (
        locality_demand["demand_norm"] -
        locality_demand["supply_norm"]
    )

    gap_top10 = locality_demand.nlargest(10, "opportunity_gap")
    print("\nTop opportunity-gap localities (high demand, low supply):")
    print(gap_top10[["area_locality", "centre_count", "demand_score",
                      "opportunity_gap"]].to_string(index=False))

    # ── Fig 2: Supply vs Demand scatter (opportunity gap) ─────────────────
    fig, ax = plt.subplots(figsize=(11, 8))
    sc = ax.scatter(
        locality_demand["supply_norm"],
        locality_demand["demand_norm"],
        c=locality_demand["opportunity_gap"],
        cmap="RdYlGn", s=90, edgecolors="grey", linewidth=0.5, alpha=0.85
    )
    plt.colorbar(sc, ax=ax, label="Opportunity Gap Score")
    # Label top opportunity localities
    for _, row in gap_top10.head(6).iterrows():
        ax.annotate(
            row["area_locality"],
            (row["supply_norm"], row["demand_norm"]),
            textcoords="offset points", xytext=(8, 4),
            fontsize=8, color=BRAND_GREEN,
            arrowprops=dict(arrowstyle="-", color="grey", lw=0.6)
        )
    ax.axline((0, 0), slope=1, color="grey", linestyle="--",
              linewidth=1, label="Supply = Demand line")
    ax.set_xlabel("Supply Score (normalised centre count)")
    ax.set_ylabel("Demand Score (normalised rating × log reviews)")
    ax.set_title("Supply vs Demand Gap – Opportunity Localities in Bengaluru")
    ax.legend()
    plt.tight_layout()
    plt.savefig(f"{FIG_DIR}/fig2_opportunity_gap.png")
    plt.close()
    print("Saved fig2_opportunity_gap.png")

    # ── Fig 3: Zone-level pie chart ────────────────────────────────────────
    zone_counts = df["zone"].value_counts()
    fig, ax = plt.subplots(figsize=(7, 7))
    wedges, texts, autotexts = ax.pie(
        zone_counts.values,
        labels=zone_counts.index,
        autopct="%1.1f%%",
        colors=[BRAND_BLUE, BRAND_ORANGE, BRAND_GREEN, BRAND_RED, BRAND_PURPLE],
        startangle=140,
        pctdistance=0.82,
        wedgeprops=dict(edgecolor="white", linewidth=2),
    )
    for t in autotexts:
        t.set_fontsize(10)
        t.set_fontweight("bold")
    ax.set_title("Fitness Centre Distribution by Zone – Bengaluru")
    plt.tight_layout()
    plt.savefig(f"{FIG_DIR}/fig3_zone_distribution.png")
    plt.close()
    print("Saved fig3_zone_distribution.png")

    return locality_counts, locality_demand


# ---------------------------------------------------------------------------
# 4.2 Proximity & Opportunity Score Analysis
# ---------------------------------------------------------------------------
def analysis_proximity(df, locality_demand):
    print("\n── 4.2 Target Demographic Proximity Analysis ──")

    prox_df = pd.DataFrame.from_dict(
        PROXIMITY, orient="index",
        columns=["college_score", "it_park_score", "metro_score"]
    ).reset_index().rename(columns={"index": "area_locality"})

    # Composite opportunity score = 40% IT + 30% Metro + 30% College
    prox_df["opportunity_score"] = (
        0.40 * prox_df["it_park_score"] +
        0.30 * prox_df["metro_score"] +
        0.30 * prox_df["college_score"]
    )

    # Merge with supply data
    merged = prox_df.merge(
        locality_demand[["area_locality", "centre_count", "avg_rating"]],
        on="area_locality", how="left"
    ).fillna({"centre_count": 0, "avg_rating": 0})

    # Final score: high opportunity + moderate-to-low supply = best entry
    merged["final_score"] = (
        merged["opportunity_score"] /
        np.log1p(merged["centre_count"])
    )

    top_entry = merged.nlargest(10, "final_score")
    print("Top 10 localities for market entry:")
    print(top_entry[["area_locality", "opportunity_score", "centre_count",
                      "final_score"]].to_string(index=False))

    # ── Fig 4: Composite Opportunity Score heatmap-style bar ─────────────
    top12 = merged.nlargest(12, "opportunity_score")
    fig, ax = plt.subplots(figsize=(12, 6))
    x = np.arange(len(top12))
    w = 0.25
    ax.bar(x - w,     top12["college_score"],  w, label="College proximity", color=BRAND_BLUE)
    ax.bar(x,         top12["it_park_score"],  w, label="IT Park proximity",  color=BRAND_ORANGE)
    ax.bar(x + w,     top12["metro_score"],    w, label="Metro proximity",    color=BRAND_GREEN)
    ax.plot(x, top12["opportunity_score"], "o--", color=BRAND_RED,
            label="Composite score", linewidth=2, markersize=6)
    ax.set_xticks(x)
    ax.set_xticklabels(top12["area_locality"], rotation=35, ha="right", fontsize=8)
    ax.set_ylabel("Score (0–10)")
    ax.set_title("Demographic Proximity Scores by Locality (Top 12)")
    ax.legend(loc="upper right", fontsize=8)
    plt.tight_layout()
    plt.savefig(f"{FIG_DIR}/fig4_proximity_scores.png")
    plt.close()
    print("Saved fig4_proximity_scores.png")

    return merged, top_entry


# ---------------------------------------------------------------------------
# 4.3 Category-wise Analysis
# ---------------------------------------------------------------------------
def analysis_category(df):
    print("\n── 4.3 Category-wise Analysis ──")

    cat_stats = (
        df.groupby("category")
        .agg(
            count=("fitness_centre_name", "count"),
            avg_rating=("rating", "mean"),
            avg_reviews=("number_of_reviews", "mean"),
        )
        .reset_index()
        .sort_values("count", ascending=False)
    )
    print(cat_stats.to_string(index=False))

    # ── Fig 5: Category count + avg rating dual-axis ─────────────────────
    fig, ax1 = plt.subplots(figsize=(13, 6))
    x = np.arange(len(cat_stats))
    bars = ax1.bar(x, cat_stats["count"], color=PALETTE[:len(cat_stats)],
                   edgecolor="white", zorder=2)
    for bar, val in zip(bars, cat_stats["count"]):
        ax1.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 2,
                 str(val), ha="center", va="bottom", fontsize=9, fontweight="bold")
    ax1.set_xticks(x)
    ax1.set_xticklabels(
        [c.replace(" / ", "/\n").replace(" Training Centre", "\nTraining Centre")
         for c in cat_stats["category"]],
        rotation=20, ha="right", fontsize=8
    )
    ax1.set_ylabel("Number of Centres", color=BRAND_BLUE)
    ax1.set_title("Fitness Category – Count & Average Rating Across Bengaluru")
    ax1.set_ylim(0, cat_stats["count"].max() * 1.15)

    ax2 = ax1.twinx()
    ax2.plot(x, cat_stats["avg_rating"], "D--", color=BRAND_ORANGE,
             linewidth=2.5, markersize=8, label="Avg Rating", zorder=3)
    ax2.set_ylabel("Average Rating (0–5)", color=BRAND_ORANGE)
    ax2.set_ylim(3.0, 5.0)
    ax2.spines["right"].set_visible(True)

    fig.legend(["Avg Rating"], loc="upper right",
               bbox_to_anchor=(0.95, 0.92), fontsize=9)
    plt.tight_layout()
    plt.savefig(f"{FIG_DIR}/fig5_category_analysis.png")
    plt.close()
    print("Saved fig5_category_analysis.png")

    # ── Fig 6: Category market share donut chart ─────────────────────────
    fig, ax = plt.subplots(figsize=(8, 8))
    wedges, texts, autotexts = ax.pie(
        cat_stats["count"],
        labels=None,
        autopct=lambda p: f"{p:.1f}%" if p > 4 else "",
        colors=PALETTE,
        startangle=90,
        pctdistance=0.78,
        wedgeprops=dict(width=0.55, edgecolor="white", linewidth=2),
    )
    ax.legend(
        wedges, cat_stats["category"],
        title="Category", loc="center left",
        bbox_to_anchor=(1.0, 0.5), fontsize=8,
    )
    ax.set_title("Fitness Category Market Share – Bengaluru", pad=20)
    plt.tight_layout()
    plt.savefig(f"{FIG_DIR}/fig6_category_share.png")
    plt.close()
    print("Saved fig6_category_share.png")

    return cat_stats


# ---------------------------------------------------------------------------
# 4.4 Rating & Review Analysis
# ---------------------------------------------------------------------------
def analysis_ratings(df):
    print("\n── 4.4 Rating & Review Analysis ──")

    # ── Fig 7: Rating distribution histogram ────────────────────────────
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    # Histogram
    ax = axes[0]
    n, bins, patches = ax.hist(
        df["rating"].dropna(), bins=20,
        color=BRAND_BLUE, edgecolor="white", alpha=0.85
    )
    ax.axvline(df["rating"].mean(), color=BRAND_ORANGE, linestyle="--",
               linewidth=2, label=f"Mean = {df['rating'].mean():.2f}")
    ax.axvline(df["rating"].median(), color=BRAND_GREEN, linestyle=":",
               linewidth=2, label=f"Median = {df['rating'].median():.2f}")
    ax.set_xlabel("Rating (0–5)")
    ax.set_ylabel("Number of Fitness Centres")
    ax.set_title("Distribution of Ratings – Bengaluru Fitness Centres")
    ax.legend()

    # KDE
    ax2 = axes[1]
    rating_clean = df["rating"].dropna()
    sns.kdeplot(rating_clean, ax=ax2, color=BRAND_BLUE, fill=True, alpha=0.3)
    ax2.set_xlabel("Rating")
    ax2.set_ylabel("Density")
    ax2.set_title("Rating Density Curve")
    ax2.axvline(rating_clean.mean(), color=BRAND_ORANGE, linestyle="--",
                linewidth=1.8, label=f"Mean={rating_clean.mean():.2f}")
    ax2.legend()

    plt.suptitle("Rating Analysis – Bengaluru Fitness Centres", fontweight="bold", y=1.01)
    plt.tight_layout()
    plt.savefig(f"{FIG_DIR}/fig7_rating_distribution.png")
    plt.close()
    print("Saved fig7_rating_distribution.png")

    # ── Top 10 centres (50+ reviews) ─────────────────────────────────────
    top10 = (
        df[df["number_of_reviews"] >= 50]
        .nlargest(10, "rating")[
            ["fitness_centre_name", "area_locality",
             "category", "rating", "number_of_reviews"]
        ]
    )
    print("\nTop 10 highest-rated centres (50+ reviews):")
    print(top10.to_string(index=False))

    # ── Fig 8: Top 10 centres horizontal bar ────────────────────────────
    fig, ax = plt.subplots(figsize=(12, 6))
    colors_top = [PALETTE[i % len(PALETTE)] for i in range(len(top10))]
    bars = ax.barh(
        [f"{r.fitness_centre_name[:28]}\n({r.area_locality})"
         for r in top10.itertuples()],
        top10["rating"].values,
        color=colors_top[::-1], edgecolor="white", height=0.7
    )
    for bar, val in zip(bars, top10["rating"].values):
        ax.text(val + 0.01, bar.get_y() + bar.get_height() / 2,
                f"{val:.1f} ★", va="center", fontsize=9)
    ax.set_xlabel("Rating")
    ax.set_xlim(3.5, 5.3)
    ax.set_title("Top 10 Highest-Rated Fitness Centres (min 50 Reviews) – Bengaluru")
    plt.tight_layout()
    plt.savefig(f"{FIG_DIR}/fig8_top10_centres.png")
    plt.close()
    print("Saved fig8_top10_centres.png")

    # ── Fig 9: Rating vs Reviews scatter (log scale) ─────────────────────
    sample = df.sample(min(500, len(df)), random_state=42)
    fig, ax = plt.subplots(figsize=(10, 6))
    scatter = ax.scatter(
        np.log1p(sample["number_of_reviews"]),
        sample["rating"],
        c=[PALETTE[i % len(PALETTE)] for i in range(len(sample))],
        alpha=0.45, s=25, edgecolors="none"
    )
    # Regression line
    mask = sample["rating"].notna() & sample["number_of_reviews"].notna()
    x_vals = np.log1p(sample.loc[mask, "number_of_reviews"])
    y_vals = sample.loc[mask, "rating"]
    slope, intercept, r_value, p_value, _ = stats.linregress(x_vals, y_vals)
    x_line = np.linspace(x_vals.min(), x_vals.max(), 100)
    ax.plot(x_line, slope * x_line + intercept, color=BRAND_RED,
            linewidth=2, label=f"Trend (r={r_value:.2f}, p={p_value:.3f})")
    ax.set_xlabel("ln(Reviews + 1)")
    ax.set_ylabel("Rating")
    ax.set_title("Correlation: Rating vs Number of Reviews")
    ax.legend()
    plt.tight_layout()
    plt.savefig(f"{FIG_DIR}/fig9_rating_vs_reviews.png")
    plt.close()
    print("Saved fig9_rating_vs_reviews.png")

    # ── Quality hotspots (avg rating by locality, min 5 centres) ─────────
    quality = (
        df.groupby("area_locality")
        .agg(avg_rating=("rating", "mean"), count=("rating", "count"))
        .query("count >= 5")
        .sort_values("avg_rating", ascending=False)
        .head(12)
        .reset_index()
    )

    # ── Fig 10: Quality hotspot bar ───────────────────────────────────────
    fig, ax = plt.subplots(figsize=(12, 5))
    bars = ax.bar(
        quality["area_locality"], quality["avg_rating"],
        color=[BRAND_GREEN if r >= 4.2 else BRAND_ORANGE if r >= 4.0 else BRAND_BLUE
               for r in quality["avg_rating"]],
        edgecolor="white"
    )
    ax.axhline(df["rating"].mean(), color=BRAND_RED, linestyle="--",
               linewidth=1.5, label=f"City avg = {df['rating'].mean():.2f}")
    for bar, val in zip(bars, quality["avg_rating"]):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.01,
                f"{val:.2f}", ha="center", va="bottom", fontsize=8)
    ax.set_xticklabels(quality["area_locality"], rotation=30, ha="right")
    ax.set_ylabel("Average Rating")
    ax.set_ylim(3.6, 4.8)
    ax.set_title("Quality Hotspots – Top 12 Localities by Average Rating")
    ax.legend()
    plt.tight_layout()
    plt.savefig(f"{FIG_DIR}/fig10_quality_hotspots.png")
    plt.close()
    print("Saved fig10_quality_hotspots.png")

    return top10, quality, r_value


# ---------------------------------------------------------------------------
# 4.5 Business Recommendation summary JSON
# ---------------------------------------------------------------------------
def build_recommendation(locality_demand, proximity_merged, cat_stats, df):
    # Best area to launch: top final_score locality with high opportunity
    best_area = proximity_merged.nlargest(1, "final_score")["area_locality"].values[0]

    # Oversaturated: top 5 by supply_norm
    oversaturated = locality_demand.nlargest(5, "supply_norm")["area_locality"].tolist()

    # Underserved: top 5 by opportunity_gap
    underserved = locality_demand.nlargest(5, "opportunity_gap")["area_locality"].tolist()

    # Category with biggest gap (lowest count, high score areas)
    min_cat = cat_stats.nsmallest(3, "count")["category"].tolist()

    # Contact data completeness
    contact = (
        df.groupby("area_locality")
        .apply(lambda x: (x["phone_number"].notna() | x["email_address"].notna()).mean())
        .reset_index(name="contact_completeness")
        .sort_values("contact_completeness", ascending=False)
        .head(5)
    )
    best_outreach = contact["area_locality"].tolist()

    rec = {
        "best_area_to_launch":   best_area,
        "target_segment_fit":    ["Koramangala", "HSR Layout", "Whitefield",
                                  "Indiranagar", "Marathahalli"],
        "oversaturated_areas":   oversaturated,
        "underserved_areas":     underserved,
        "category_opportunity":  min_cat,
        "best_outreach_areas":   best_outreach,
    }
    with open(os.path.join(CLEANED_DIR, "recommendation.json"), "w") as f:
        json.dump(rec, f, indent=2)
    print("\nRecommendation JSON saved.")
    return rec


# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    os.makedirs(FIG_DIR, exist_ok=True)
    df = load_data()
    print(f"Loaded {len(df)} records from cleaned dataset")

    locality_counts, locality_demand = analysis_geographic(df)
    proximity_merged, top_entry       = analysis_proximity(df, locality_demand)
    cat_stats                          = analysis_category(df)
    top10, quality, r_val              = analysis_ratings(df)
    rec                                = build_recommendation(
                                            locality_demand, proximity_merged,
                                            cat_stats, df)

    print("\n✓ All 10 figures generated.")
    print("✓ Recommendation JSON saved.")
    print("Analysis complete.")
